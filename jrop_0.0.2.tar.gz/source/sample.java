/*
Project name :
   Dev name  :
     Date    :

using Jrop
package name = jrop_data

*/
package jrop_data;

//******************************************************************
//
//                          import module
//       
//******************************************************************

import java.lang.*;
import java.util.*;



//******************************************************************
//
//                          class section
//       
//******************************************************************

class sample{
    
	public sample(){super();}
    
    //TODO:Script your code on output()
	public	void output(){
    //output() is be a main function



	}
}
