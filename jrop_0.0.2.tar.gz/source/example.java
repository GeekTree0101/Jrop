/*
jrop test java file
*/

//test on jrop
package jrop_data;


import java.util.Scanner;

class example1{
	public example1(){

		super();
	}
	public	void output(){
		Scanner data = new Scanner (System.in); //스케너 인스턴스화
		String name; //Name
		String number; //Phone number
		
		System.out.print("Insert NAME: ");
		name = data.nextLine(); //데이터(사용자 이름)를 받아서 name String 배열에 저장
		
                System.out.print("Insert Phone_Number: ");
		number = data.nextLine(); //데이터(사용자 전화번호)를 받아서 number String 배열에 저장
		
		System.out.println("\n\n[OUTPUT] NAME : " + name + " Phone Number : " + number); //출력
	}
}

class example2{
	public example2(){

		super();
	}
	public void output(){
		Scanner num = new Scanner(System.in); 
		
		//init variable
		int first = 0;
		int second = 0;
		
		System.out.print("Insert first number : ");
		first = Integer.parseInt(num.next()); //String to int 형변환 Integer.parseInt(STRING)
		System.out.print("Insert second number : ");
		second = Integer.parseInt(num.next());


		//Decimal custom
		String dec1 = "[   +" + Integer.toString(first) + "   ]";
		String dec2 = "[   +" + Integer.toString(second) + "   ]";
		//Decimal to Oct
		String oct1 ="[   "+ Integer.toOctalString(first) + "   ]";
		String oct2 ="[   "+  Integer.toOctalString(second)  + "   ]";
		//Decimal to Hex
		String hex1 ="[   "+ Integer.toHexString(first)+ "   ]";
		String hex2 ="[   "+ Integer.toHexString(second) + "   ]";
		
		//output
		String decOutput = "[   +" + Integer.toString(first+second) + "   ]";
		String octOutput = "[   " + Integer.toOctalString(first+second) + "   ]";
		String hexOutput = "[   " + Integer.toHexString(first+second) + "    ]";

		System.out.println("[  수  ][ 10진수 ][   8진수  ][ 16진수 ]");
		System.out.println("[첫째수]" + dec1 + oct1 + hex1);
		System.out.println("[둘째수]" + dec2 + oct2 + hex2);
		System.out.println("[합  계]" + decOutput + octOutput + hexOutput);

	}
}

class example3{
	public example3(){
		
		super();
	}
	public void output(){
	
		Scanner scan = new Scanner(System.in);
		String[] splitedValue;
		String data;

		String name;
		String age;
		float weight;		

		System.out.print("Insert Data[ex. name, age, weight] : ");
		data = scan.nextLine();
		splitedValue = data.split(","); //문자열 ','단위로 자르기
	
		name = (splitedValue[0]).trim(); //이름저장
		age =  Integer.toHexString(Integer.parseInt((splitedValue[1]).trim()));
		 //공백제거 trim() -> 정수형으로 변환 -> 헥사코드로 변환 후 나이 배열에 저장
		weight = Float.parseFloat((splitedValue[2]).trim());
		//공백제거 trim() -> 실수형으로 저장
		String weight_string = String.format("%3.3f",weight);
		//실수형으로 저장된 값을 포멧을 이용하여 앞자리 3자리 뒷자리 소수점 3자리까지 트림시켜 저장		

		System.out.println("My name is '" + name + "' age is " + age + " Weight is " + weight_string  + ".");
		}
}

